//
//  PhoneNumberTextField.swift
//  PhoneNumberKit
//
//  Created by Roy Marmelstein on 07/11/2015.
//  Copyright © 2021 Roy Marmelstein. All rights reserved.
//

#if os(iOS)

import Foundation
import UIKit

/// Custom text field that formats phone numbers
open class PhoneNumberTextField: UITextField, UITextFieldDelegate {
    /// The PhoneNumberKit instance used to parse and format phone numbers.
    public let utility: PhoneNumberUtility
    /// The flag button displayed in the text field when `withFlag` is set to true.
    public lazy var flagButton = UIButton()
    /// Override setText so number will be automatically formatted when setting text by code
    override open var text: String? {
        set {
            if isPartialFormatterEnabled, let newValue = newValue {
                let formattedNumber = partialFormatter.formatPartial(newValue)
                super.text = formattedNumber
            } else {
                super.text = newValue
            }
            NotificationCenter.default.post(name: UITextField.textDidChangeNotification, object: self)
            self.updateFlag()
        }
        get {
            return super.text
        }
    }
    /// Forces textContentType to .telephoneNumber for autofill support.
    override open var textContentType: UITextContentType! {
        get { .telephoneNumber }
        set {}
    }

    /// allows text to be set without formatting
    open func setTextUnformatted(newValue: String?) {
        super.text = newValue
    }

    private lazy var _defaultRegion: String = PhoneNumberUtility.defaultRegionCode()

    /// Override region to set a custom region. Automatically uses the default region code.
    open var defaultRegion: String {
        get {
            return self._defaultRegion
        }
        @available(
            *,
            deprecated,
            message: """
                The setter of defaultRegion is deprecated,
                please override defaultRegion in a subclass instead.
            """
        )
        set {
            self.partialFormatter.defaultRegion = newValue
        }
    }
    
    /// Whether to format with the international prefix. Defaults to true.
    @IBInspectable public var withPrefix: Bool = true {
        didSet {
            self.partialFormatter.withPrefix = self.withPrefix
            if self.withPrefix == false {
                self.keyboardType = .numberPad
            } else {
                self.keyboardType = .phonePad
            }
            if self.withExamplePlaceholder {
                self.updatePlaceholder()
            }
        }
    }
    
    /// Whether to prefill the international prefix when editing begins. Defaults to true.
    public var withPrefixPrefill: Bool = true

    @IBInspectable public var withFlag: Bool = false {
        didSet {
            leftView = self.withFlag ? self.flagButton : nil
            leftViewMode = self.withFlag ? .always : .never
            self.updateFlag()
        }
    }
    
    /// Whether to show an example placeholder when the text field is empty. Defaults to false.
    @IBInspectable public var withExamplePlaceholder: Bool = false {
        didSet {
            if self.withExamplePlaceholder {
                self.updatePlaceholder()
            } else {
                attributedPlaceholder = nil
            }
        }
    }

    #if compiler(>=5.1)
    /// Available on iOS 13 and above just.
    public var countryCodePlaceholderColor: UIColor = {
        if #available(iOS 13.0, tvOS 13.0, *) {
            return .secondaryLabel
        } else {
            return UIColor(red: 0, green: 0, blue: 0.0980392, alpha: 0.22)
        }
    }() {
        didSet {
            self.updatePlaceholder()
        }
    }

    /// Available on iOS 13 and above just.
    public var numberPlaceholderColor: UIColor = {
        if #available(iOS 13.0, tvOS 13.0, *) {
            return .tertiaryLabel
        } else {
            return UIColor(red: 0, green: 0, blue: 0.0980392, alpha: 0.22)
        }
    }() {
        didSet {
            self.updatePlaceholder()
        }
    }
    #endif

    private var _withDefaultPickerUI: Bool = false {
        didSet {
            if flagButton.actions(forTarget: self, forControlEvent: .touchUpInside) == nil {
                flagButton.addTarget(self, action: #selector(didPressFlagButton), for: .touchUpInside)
            }
        }
    }
    
    /// Add click action to flag button and show country code picker when withDefaultPickerUI is true
    @IBInspectable public var withDefaultPickerUI: Bool {
        get { _withDefaultPickerUI }
        set { _withDefaultPickerUI = newValue }
    }
    
    /// Options for the default country code picker UI
    public var withDefaultPickerUIOptions: CountryCodePickerOptions = .default

    public var modalPresentationStyle: UIModalPresentationStyle?
    
    /// Enable or disable partial formatter. Defaults to true.
    public var isPartialFormatterEnabled = true
    
    /// Maximum number of digits allowed in the phone number. Defaults to nil (no limit).
    public var maxDigits: Int? {
        didSet {
            self.partialFormatter.maxDigits = self.maxDigits
        }
    }
    
    /// The type of phone number to use for the example placeholder. Defaults to `.mobile`.
    public var ofType: PhoneNumberType = .mobile {
        didSet {
            if self.withExamplePlaceholder {
                self.updatePlaceholder()
            }
        }
    }

    public private(set) lazy var partialFormatter: PartialFormatter = .init(
        utility: utility,
        defaultRegion: defaultRegion,
        withPrefix: withPrefix,
        ignoreIntlNumbers: true
    )

    let nonNumericSet: CharacterSet = {
        var mutableSet = CharacterSet.decimalDigits.inverted
        mutableSet.remove(charactersIn: PhoneNumberConstants.plusChars)
        mutableSet.remove(charactersIn: PhoneNumberConstants.pausesAndWaitsChars)
        mutableSet.remove(charactersIn: PhoneNumberConstants.operatorChars)
        return mutableSet
    }()

    private weak var _delegate: UITextFieldDelegate?

    override open var delegate: UITextFieldDelegate? {
        get {
            return self._delegate
        }
        set {
            self._delegate = newValue
        }
    }
    
    /// Allow to manage states of PhoneNumberTextField when presenting/dismissing country code picker
    public weak var stateDelegate: PhoneNumberTextFieldDelegate?
    /// To store host navigation controller delegate when pushing country code picker
    private weak var hostNavigationControllerDelegate: UINavigationControllerDelegate?
    /// To store reference to presented country code picker
    private weak var countryCodePickerViewController: CountryCodePickerViewController?

    // MARK: Status
    
    /// Returns the current region code based on the text field's content.
    public var currentRegion: String {
        return self.partialFormatter.currentRegion
    }
    
    /// Returns the current national number based on the text field's content.
    public var nationalNumber: String {
        let rawNumber = self.text ?? String()
        return self.partialFormatter.nationalNumber(from: rawNumber)
    }
    
    /// Returns whether the current phone number is valid.
    public var isValidNumber: Bool {
        let rawNumber = self.text ?? String()
        do {
            _ = try utility.parse(rawNumber, withRegion: currentRegion)
            return true
        } catch {
            return false
        }
    }

    /// Returns the current valid phone number.
    /// - returns: PhoneNumber?
    public var phoneNumber: PhoneNumber? {
        guard let rawNumber = self.text else { return nil }
        do {
            return try utility.parse(rawNumber, withRegion: currentRegion)
        } catch {
            return nil
        }
    }

    override open func layoutSubviews() {
        if self.withFlag { // update the width of the flagButton automatically, iOS <13 doesn't handle this for you
            let width = self.flagButton.systemLayoutSizeFitting(bounds.size).width
            self.flagButton.frame.size.width = width
        }
        super.layoutSubviews()
    }

    // MARK: - Insets

    private var insets: UIEdgeInsets?
    private var clearButtonPadding: CGFloat?

    // MARK: Lifecycle

    /// Init with a phone number kit instance. Because a `PhoneNumberUtility` initialization is expensive,
    /// you can pass a pre-initialized instance to avoid incurring perf penalties.
    ///
    /// - parameter utility: A `PhoneNumberUtility` instance to be used by the text field.
    ///
    /// - returns: UITextfield
    @available(*, deprecated, message: "PhoneNumberKit's UI components have moved to github.com/PhoneNumberKit/PhoneNumberKitUI; this repository is no longer maintained. See the README to migrate.")
    public convenience init(utility: PhoneNumberUtility) {
        self.init(frame: .zero, utility: utility)
    }

    /// Init with frame and phone number kit instance.
    ///
    /// - parameter frame: UITextfield frame
    /// - parameter utility: A `PhoneNumberUtility` instance to be used by the text field.
    ///
    /// - returns: UITextfield
    @available(*, deprecated, message: "PhoneNumberKit's UI components have moved to github.com/PhoneNumberKit/PhoneNumberKitUI; this repository is no longer maintained. See the README to migrate.")
    public init(frame: CGRect, utility: PhoneNumberUtility) {
        self.utility = utility
        super.init(frame: frame)
        self.setup()
    }

    /// Init with frame
    ///
    /// - parameter frame: UITextfield F
    ///
    /// - returns: UITextfield
    @available(*, deprecated, message: "PhoneNumberKit's UI components have moved to github.com/PhoneNumberKit/PhoneNumberKitUI; this repository is no longer maintained. See the README to migrate.")
    override public init(frame: CGRect) {
        self.utility = PhoneNumberUtility()
        super.init(frame: frame)
        self.setup()
    }

    /// Initialize an instance with specific insets and clear button padding.
    ///
    /// This initializer creates an instance of the class with custom UIEdgeInsets and padding for the clear button.
    /// Both of these parameters are used to customize the appearance of the text field and its clear button within the class.
    ///
    /// - Parameters:
    ///   - insets: The UIEdgeInsets to be applied to the text field's bounding rectangle. These insets define the padding
    ///     that is applied within the text field's bounding rectangle. A UIEdgeInsets value contains insets for
    ///     each of the four directions (top, bottom, left, right). Positive values move the content toward the center of the
    ///     text field, and negative values move the content toward the edges of the text field.
    ///   - clearButtonPadding: The padding to be applied to the clear button. This value defines the space between the clear
    ///     button and the edges of the text field. A positive value increases the distance between the clear button and the
    ///     text field's edges, and a negative value decreases this distance.
    @available(*, deprecated, message: "PhoneNumberKit's UI components have moved to github.com/PhoneNumberKit/PhoneNumberKitUI; this repository is no longer maintained. See the README to migrate.")
    public init(insets: UIEdgeInsets, clearButtonPadding: CGFloat) {
        self.utility = PhoneNumberUtility()
        self.insets = insets
        self.clearButtonPadding = clearButtonPadding
        super.init(frame: .zero)
        self.setup()
    }

    /// Init with coder
    ///
    /// - parameter aDecoder: decoder
    ///
    /// - returns: UITextfield
    public required init(coder aDecoder: NSCoder) {
        self.utility = PhoneNumberUtility()
        super.init(coder: aDecoder)!
        self.setup()
    }

    open func setup() {
        self.autocorrectionType = .no
        self.keyboardType = .phonePad
        super.delegate = self
    }

    func internationalPrefix(for countryCode: String) -> String? {
        guard let countryCode = utility.countryCode(for: currentRegion)?.description else { return nil }
        return "+" + countryCode
    }

    open func updateFlag() {
        guard self.withFlag else { return }

        if let phoneNumber = phoneNumber,
           let regionCode = phoneNumber.regionID,
           regionCode != currentRegion,
           phoneNumber.countryCode == utility.countryCode(for: currentRegion) {
            _defaultRegion = regionCode
            partialFormatter.defaultRegion = regionCode
        }

        let flagBase = UnicodeScalar("🇦").value - UnicodeScalar("A").value

        let flag = self.currentRegion
            .uppercased()
            .unicodeScalars
            .compactMap { UnicodeScalar(flagBase + $0.value)?.description }
            .joined()

        self.flagButton.setTitle(flag + " ", for: .normal)
        self.flagButton.accessibilityLabel = NSLocalizedString(
            "PhoneNumberKit.CountryCodePickerEntryButton.AccessibilityLabel",
            value: "Select your country code",
            comment: "Accessibility Label for Country Code Picker button")

        if let countryName = Locale.autoupdatingCurrent.localizedString(forRegionCode: self.currentRegion) {
            let selectedFormat = NSLocalizedString(
                "PhoneNumberKit.CountryCodePickerEntryButton.AccessibilityHint",
                value: "%@ selected",
                comment: "Accessiblity hint for currently selected country code")
            self.flagButton.accessibilityHint = String(format: selectedFormat, countryName)
        }
        let fontSize = (font ?? UIFont.preferredFont(forTextStyle: .body)).pointSize
        self.flagButton.titleLabel?.font = UIFont.systemFont(ofSize: fontSize)
    }

    open func updatePlaceholder() {
        guard self.withExamplePlaceholder else { return }
        if isEditing, !(self.text ?? "").isEmpty { return } // No need to update a placeholder while the placeholder isn't showing

        let format = self.withPrefix ? PhoneNumberFormat.international : .national
        let example = self.utility.getFormattedExampleNumber(forCountry: self.currentRegion, ofType: self.ofType, withFormat: format, withPrefix: self.withPrefix) ?? "12345678"
        let font = self.font ?? UIFont.preferredFont(forTextStyle: .body)
        let ph = NSMutableAttributedString(string: example, attributes: [.font: font])

        #if compiler(>=5.1)
        if #available(iOS 13.0, *), self.withPrefix {
            // because the textfield will automatically handle insert & removal of the international prefix we make the
            // prefix darker to indicate non default behaviour to users, this behaviour currently only happens on iOS 13
            // and above just because that is where we have access to label colors
            let firstSpaceIndex = example.firstIndex(where: { $0 == " " }) ?? example.startIndex

            ph.addAttribute(.foregroundColor, value: self.countryCodePlaceholderColor, range: NSRange(..<firstSpaceIndex, in: example))
            ph.addAttribute(.foregroundColor, value: self.numberPlaceholderColor, range: NSRange(firstSpaceIndex..., in: example))
        }
        #endif

        self.attributedPlaceholder = ph
    }

    @objc open func didPressFlagButton() {
        guard withDefaultPickerUI else { return }
        let vc = CountryCodePickerViewController(utility: utility,
                                                 options: withDefaultPickerUIOptions)
        countryCodePickerViewController = vc
        vc.delegate = self
        stateDelegate?.countryCodePickerViewControllerWillPresent(self, controller: vc)
        if let nav = containingViewController?.navigationController, !CountryCodePicker.forceModalPresentation {
            if let _ = stateDelegate { // store host delegate only if we have a state delegate
                if let hostDelegate = nav.delegate,
                   !hostDelegate.isKind(of: PhoneNumberTextField.self) {
                    // host delegate shouldn't be self to avoid retain cycle
                } else {
                    hostNavigationControllerDelegate = nav.delegate
                    nav.delegate = self
                }
            }
            CATransaction.begin()
            CATransaction.setCompletionBlock({ [weak self, weak vc] in
                guard let self, let vc else { return }
                stateDelegate?.countryCodePickerViewControllerDidPresent(self, controller: vc)
            })
            nav.pushViewController(vc, animated: true)
            CATransaction.commit()
        } else {
            let nav = UINavigationController(rootViewController: vc)
            if modalPresentationStyle != nil {
                nav.modalPresentationStyle = modalPresentationStyle!
            }
            containingViewController?.present(nav, animated: true, completion: { [weak self, weak vc] in
                guard let self, let vc else { return }
                stateDelegate?.countryCodePickerViewControllerDidPresent(self, controller: vc)
            })
        }
    }

    /// containingViewController looks at the responder chain to find the view controller nearest to itself
    var containingViewController: UIViewController? {
        var responder: UIResponder? = self
        while !(responder is UIViewController), responder != nil {
            responder = responder?.next
        }
        return (responder as? UIViewController)
    }

    // MARK: Phone number formatting

    ///  To keep the cursor position, we find the character immediately after the cursor and count the number of times it repeats in the remaining string as this will remain constant in every kind of editing.

    struct CursorPosition {
        let numberAfterCursor: String
        let repetitionCountFromEnd: Int
    }

    func extractCursorPosition() -> CursorPosition? {
        var repetitionCountFromEnd = 0
        // Check that there is text in the UITextField
        guard let text = text, let selectedTextRange = selectedTextRange else {
            return nil
        }
        let textAsNSString = text as NSString
        let cursorEnd = offset(from: beginningOfDocument, to: selectedTextRange.end)
        // Look for the next valid number after the cursor, when found return a CursorPosition struct
        for i in cursorEnd..<textAsNSString.length {
            let cursorRange = NSRange(location: i, length: 1)
            let candidateNumberAfterCursor: NSString = textAsNSString.substring(with: cursorRange) as NSString
            if candidateNumberAfterCursor.rangeOfCharacter(from: self.nonNumericSet).location == NSNotFound {
                for j in cursorRange.location..<textAsNSString.length {
                    let candidateCharacter = textAsNSString.substring(with: NSRange(location: j, length: 1))
                    if candidateCharacter == candidateNumberAfterCursor as String {
                        repetitionCountFromEnd += 1
                    }
                }
                return CursorPosition(numberAfterCursor: candidateNumberAfterCursor as String, repetitionCountFromEnd: repetitionCountFromEnd)
            }
        }
        return nil
    }

    // Finds position of previous cursor in new formatted text
    func selectionRangeForNumberReplacement(textField: UITextField, formattedText: String) -> NSRange? {
        let textAsNSString = formattedText as NSString
        var countFromEnd = 0
        guard let cursorPosition = extractCursorPosition() else {
            return nil
        }

        for i in stride(from: textAsNSString.length - 1, through: 0, by: -1) {
            let candidateRange = NSRange(location: i, length: 1)
            let candidateCharacter = textAsNSString.substring(with: candidateRange)
            if candidateCharacter == cursorPosition.numberAfterCursor {
                countFromEnd += 1
                if countFromEnd == cursorPosition.repetitionCountFromEnd {
                    return candidateRange
                }
            }
        }

        return nil
    }

    open func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let text = text else {
            return false
        }

        // allow delegate to intervene
        guard self._delegate?.textField?(textField, shouldChangeCharactersIn: range, replacementString: string) ?? true else {
            return false
        }
        guard self.isPartialFormatterEnabled else {
            return true
        }

        // This allows for the case when a user autocompletes a phone number:
        if range == NSRange(location: 0, length: 0), string.isBlank {
            return true
        }

        let textAsNSString = text as NSString
        let changedRange = textAsNSString.substring(with: range) as NSString
        let modifiedTextField = textAsNSString.replacingCharacters(in: range, with: string)

        let filteredCharacters = modifiedTextField.filter {
            String($0).rangeOfCharacter(from: (textField as! PhoneNumberTextField).nonNumericSet) == nil
        }
        let rawNumberString = String(filteredCharacters)

        let formattedNationalNumber = self.partialFormatter.formatPartial(rawNumberString as String)
        var selectedTextRange: NSRange?

        let nonNumericRange = (changedRange.rangeOfCharacter(from: self.nonNumericSet).location != NSNotFound)
        if range.length == 1, string.isEmpty, nonNumericRange {
            selectedTextRange = self.selectionRangeForNumberReplacement(textField: textField, formattedText: modifiedTextField)
            textField.text = modifiedTextField
        } else {
            selectedTextRange = self.selectionRangeForNumberReplacement(textField: textField, formattedText: formattedNationalNumber)
            textField.text = formattedNationalNumber
        }
        sendActions(for: .editingChanged)
        if let selectedTextRange = selectedTextRange, let selectionRangePosition = textField.position(from: beginningOfDocument, offset: selectedTextRange.location) {
            let selectionRange = textField.textRange(from: selectionRangePosition, to: selectionRangePosition)
            textField.selectedTextRange = selectionRange
        }

        // we change the default region to be the one most recently typed
        // but only when the withFlag is true as to not confuse the user who don't see the flag
        if withFlag == true {
            self._defaultRegion = self.currentRegion
            self.partialFormatter.defaultRegion = self.currentRegion
            self.updateFlag()
            self.updatePlaceholder()
        }

        return false
    }

    // MARK: UITextfield Delegate

    open func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return self._delegate?.textFieldShouldBeginEditing?(textField) ?? true
    }

    open func textFieldDidBeginEditing(_ textField: UITextField) {
        if self.withExamplePlaceholder, self.withPrefixPrefill, self.withPrefix, let countryCode = utility.countryCode(for: currentRegion)?.description, (text ?? "").isEmpty {
            text = "+" + countryCode + " "
        }
        self._delegate?.textFieldDidBeginEditing?(textField)
    }

    open func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        return self._delegate?.textFieldShouldEndEditing?(textField) ?? true
    }

    open func textFieldDidEndEditing(_ textField: UITextField) {
        updateTextFieldDidEndEditing(textField)
        self._delegate?.textFieldDidEndEditing?(textField)
    }

    open func textFieldDidEndEditing(_ textField: UITextField, reason: UITextField.DidEndEditingReason) {
        updateTextFieldDidEndEditing(textField)
        if let _delegate = _delegate {
            if _delegate.responds(to: #selector(textFieldDidEndEditing(_:reason:))) {
                _delegate.textFieldDidEndEditing?(textField, reason: reason)
            } else {
                _delegate.textFieldDidEndEditing?(textField)
            }
        }
    }

    open func textFieldShouldClear(_ textField: UITextField) -> Bool {
        return self._delegate?.textFieldShouldClear?(textField) ?? true
    }

    open func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return self._delegate?.textFieldShouldReturn?(textField) ?? true
    }

    @available(iOS 13.0, tvOS 13.0, *)
    open func textFieldDidChangeSelection(_ textField: UITextField) {
        self._delegate?.textFieldDidChangeSelection?(textField)
    }

    private func updateTextFieldDidEndEditing(_ textField: UITextField) {
        if self.withExamplePlaceholder, self.withPrefix, let countryCode = utility.countryCode(for: currentRegion)?.description,
           let text = textField.text,
           text == internationalPrefix(for: countryCode) {
            textField.text = ""
            sendActions(for: .editingChanged)
            self.updateFlag()
            self.updatePlaceholder()
        }
    }
}

// MARK: - UINavigationControllerDelegate

extension PhoneNumberTextField: CountryCodePickerDelegate {
    public func countryCodePickerViewControllerDidPickCountry(_ country: CountryCodePickerViewController.Country) {
        text = isEditing ? "+" + country.prefix : ""
        _defaultRegion = country.code
        partialFormatter.defaultRegion = country.code
        updateFlag()
        updatePlaceholder()
        if let nav = containingViewController?.navigationController, !CountryCodePicker.forceModalPresentation {
            nav.popViewController(animated: true)
        } else {
            if let countryCodePickerViewController {
                stateDelegate?.countryCodePickerViewControllerWillDismiss(self, controller: countryCodePickerViewController)
            }
            containingViewController?.dismiss(animated: true, completion: { [weak self] in
                guard let self else { return }
                countryCodePickerViewController = nil
                stateDelegate?.countryCodePickerViewControllerDidDismiss(self)
            })
        }
    }
    
    public func countryCodePickerViewControllerWillDissmiss(_ controller: CountryCodePickerViewController) {
        stateDelegate?.countryCodePickerViewControllerWillDismiss(self, controller: controller)
    }
    
    public func countryCodePickerViewControllerDidDissmiss() {
        stateDelegate?.countryCodePickerViewControllerDidDismiss(self)
    }
}

// MARK: - UINavigationControllerDelegate
extension PhoneNumberTextField: UINavigationControllerDelegate {
    public func navigationController(_ navigationController: UINavigationController, willShow viewController: UIViewController, animated: Bool) {
        if let countryCodePickerViewController,
           !viewController.isKind(of: CountryCodePickerViewController.self) {
            stateDelegate?.countryCodePickerViewControllerWillDismiss(self, controller: countryCodePickerViewController)
        }
        hostNavigationControllerDelegate?.navigationController?(navigationController, willShow: viewController, animated: animated)
    }

    public func navigationController(_ navigationController: UINavigationController, didShow viewController: UIViewController, animated: Bool) {
        if !viewController.isKind(of: CountryCodePickerViewController.self) {
            hostNavigationControllerDelegate?.navigationController?(navigationController, didShow: viewController, animated: animated)
            containingViewController?.navigationController?.delegate = hostNavigationControllerDelegate
            hostNavigationControllerDelegate = nil
            countryCodePickerViewController = nil
            stateDelegate?.countryCodePickerViewControllerDidDismiss(self)
        } else {
            hostNavigationControllerDelegate?.navigationController?(navigationController, didShow: viewController, animated: animated)
        }
    }
    // Just forwarding methods
    public func navigationControllerSupportedInterfaceOrientations(_ navigationController: UINavigationController) -> UIInterfaceOrientationMask {
        return hostNavigationControllerDelegate?.navigationControllerSupportedInterfaceOrientations?(navigationController) ?? .all
    }
    
    public func navigationControllerPreferredInterfaceOrientationForPresentation(_ navigationController: UINavigationController) -> UIInterfaceOrientation {
        return hostNavigationControllerDelegate?.navigationControllerPreferredInterfaceOrientationForPresentation?(navigationController) ?? .portrait
    }
    
    public func navigationController(_ navigationController: UINavigationController, interactionControllerFor animationController: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
        return hostNavigationControllerDelegate?.navigationController?(navigationController, interactionControllerFor: animationController)
    }
    
    public func navigationController(_ navigationController: UINavigationController, animationControllerFor operation: UINavigationController.Operation, from fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return hostNavigationControllerDelegate?.navigationController?(navigationController, animationControllerFor: operation, from: fromVC, to: toVC)
    }
}

// MARK: - Insets

extension PhoneNumberTextField {
    override open func textRect(forBounds bounds: CGRect) -> CGRect {
        if let insets = self.insets {
            return super.textRect(forBounds: bounds.inset(by: insets))
        } else {
            return super.textRect(forBounds: bounds)
        }
    }

    override open func editingRect(forBounds bounds: CGRect) -> CGRect {
        if let insets = self.insets {
            return super.editingRect(forBounds: bounds
                .inset(by: insets))
        } else {
            return super.editingRect(forBounds: bounds)
        }
    }

    override open func clearButtonRect(forBounds bounds: CGRect) -> CGRect {
        if let insets = self.insets,
           let clearButtonPadding = self.clearButtonPadding {
            return super.clearButtonRect(forBounds: bounds.insetBy(dx: insets.left - clearButtonPadding, dy: 0))
        } else {
            return super.clearButtonRect(forBounds: bounds)
        }
    }
}

extension String {
    var isBlank: Bool {
        return allSatisfy(\.isWhitespace)
    }
}

#endif
